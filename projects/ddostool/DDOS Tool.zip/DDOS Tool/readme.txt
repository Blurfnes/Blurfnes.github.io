to start the ddos tool, run the app in this folder and follow further instructions##


created by blurfnes